There are two files contained in this zip file related to the code challenge:

fl_code_challenge_python.ipynb contains instructions for the code challenge in python.

fl_code_challenge_r.Rmd contains instructions for the code challenge in R.

The code challenge is the same for both files, only the language (R or Python) is different.
Please select one and complete it.
If you are feeling confident in your abilities,
you are welcome to complete the challenge in both languages, but this is not a requirement.
This challenge should take no more than two hours max to complete.
